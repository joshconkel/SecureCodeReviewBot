# Merged Security Review Summary

**Overall Decision: FAIL**  |  Files scanned: 50  |  FAIL: 23  |  NEEDS_HUMAN: 25  |  PASS: 2

## FAIL Files
- WebGoat/AddNewUser.aspx.cs
- WebGoat/dbtest.aspx.cs
- WebGoat/dbtest.aspx.designer.cs
- WebGoat/Default.aspx.cs
- WebGoat/ForgotPassword.aspx.cs
- WebGoat/Global.asax.cs
- WebGoat/LoginPage.aspx.cs
- WebGoat/Web.config
- WebGoat/WebGoat.NET.csproj
- WebGoat/App_Code/Encoder.cs
- WebGoat/App_Code/Util.cs
- WebGoat/App_Code/WeakRandom.cs
- WebGoat/App_Code/DB/MySqlDbProvider.cs
- WebGoat/App_Code/DB/SqliteDbProvider.cs
- WebGoat/App_Data/XmlInjectionUsers.xml
- WebGoat/Code/DatabaseUtilities.cs
- WebGoat/Code/SQLiteMembershipProvider.cs
- WebGoat/Code/SQLiteProfileProvider.cs
- WebGoat/Code/SQLiteRoleProvider.cs
- WebGoat/Content/BasicAuth.aspx.cs
- WebGoat/Content/Challenge1.aspx.cs
- WebGoat/Content/Challenge2.aspx.cs
- WebGoat/Content/ChangePwd.aspx.cs

## NEEDS_HUMAN Files
- WebGoat/AddNewUser.aspx.designer.cs
- WebGoat/ChangePassword.aspx.cs
- WebGoat/ChangePassword.aspx.designer.cs
- WebGoat/Default.aspx.designer.cs
- WebGoat/ForgotPassword.aspx.designer.cs
- WebGoat/LoginPage.aspx.designer.cs
- WebGoat/ProxySetup.aspx.cs
- WebGoat/ProxySetup.aspx.designer.cs
- WebGoat/App_Code/ConfigFile.cs
- WebGoat/App_Code/CookieManager.cs
- WebGoat/App_Code/Settings.cs
- WebGoat/App_Code/VeryWeakRandom.cs
- WebGoat/App_Code/WeakMessageDigest.cs
- WebGoat/App_Code/DB/DbConstants.cs
- WebGoat/App_Code/DB/DummyDbProvider.cs
- WebGoat/App_Code/DB/IDbProvider.cs
- WebGoat/Code/IOHelper.cs
- WebGoat/Configuration/Default.config
- WebGoat/Content/About.aspx.cs
- WebGoat/Content/About.aspx.designer.cs
- WebGoat/Content/BasicAuth.aspx.designer.cs
- WebGoat/Content/Challenge1.aspx.designer.cs
- WebGoat/Content/Challenge2.aspx.designer.cs
- WebGoat/Content/Challenge3.aspx.cs
- WebGoat/Content/Challenge3.aspx.designer.cs

## All Results
| File | Decision | Pre-scan | Findings | Blockers |
|------|----------|----------|----------|----------|
| WebGoat/AddNewUser.aspx.cs | FAIL | 1 | 3 | 2 |
| WebGoat/AddNewUser.aspx.designer.cs | NEEDS_HUMAN | 0 | 3 | 1 |
| WebGoat/ChangePassword.aspx.cs | NEEDS_HUMAN | 0 | 2 | 1 |
| WebGoat/ChangePassword.aspx.designer.cs | NEEDS_HUMAN | 0 | 2 | 2 |
| WebGoat/dbtest.aspx.cs | FAIL | 3 | 5 | 3 |
| WebGoat/dbtest.aspx.designer.cs | FAIL | 0 | 3 | 2 |
| WebGoat/Default.aspx.cs | FAIL | 2 | 2 | 1 |
| WebGoat/Default.aspx.designer.cs | NEEDS_HUMAN | 0 | 2 | 2 |
| WebGoat/ForgotPassword.aspx.cs | FAIL | 0 | 2 | 2 |
| WebGoat/ForgotPassword.aspx.designer.cs | NEEDS_HUMAN | 0 | 0 | 0 |
| WebGoat/Global.asax.cs | FAIL | 1 | 4 | 2 |
| WebGoat/LoginPage.aspx.cs | FAIL | 1 | 3 | 2 |
| WebGoat/LoginPage.aspx.designer.cs | NEEDS_HUMAN | 0 | 2 | 0 |
| WebGoat/ProxySetup.aspx.cs | NEEDS_HUMAN | 0 | 3 | 0 |
| WebGoat/ProxySetup.aspx.designer.cs | NEEDS_HUMAN | 0 | 0 | 0 |
| WebGoat/Web.config | FAIL | 5 | 5 | 3 |
| WebGoat/WebGoat.NET.csproj | FAIL | 3 | 3 | 3 |
| WebGoat/App_Code/ConfigFile.cs | NEEDS_HUMAN | 1 | 1 | 0 |
| WebGoat/App_Code/CookieManager.cs | NEEDS_HUMAN | 1 | 1 | 0 |
| WebGoat/App_Code/CustomerLoginData.cs | PASS | 2 | 2 | 0 |
| WebGoat/App_Code/Encoder.cs | FAIL | 3 | 3 | 1 |
| WebGoat/App_Code/Settings.cs | NEEDS_HUMAN | 1 | 1 | 0 |
| WebGoat/App_Code/Util.cs | FAIL | 2 | 5 | 2 |
| WebGoat/App_Code/VeryWeakRandom.cs | NEEDS_HUMAN | 1 | 1 | 1 |
| WebGoat/App_Code/WeakMessageDigest.cs | NEEDS_HUMAN | 1 | 1 | 0 |
| WebGoat/App_Code/WeakRandom.cs | FAIL | 1 | 1 | 1 |
| WebGoat/App_Code/DB/DbConstants.cs | NEEDS_HUMAN | 0 | 0 | 0 |
| WebGoat/App_Code/DB/DbProviderFactory.cs | PASS | 0 | 2 | 0 |
| WebGoat/App_Code/DB/DummyDbProvider.cs | NEEDS_HUMAN | 0 | 3 | 0 |
| WebGoat/App_Code/DB/IDbProvider.cs | NEEDS_HUMAN | 0 | 3 | 0 |
| WebGoat/App_Code/DB/MySqlDbProvider.cs | FAIL | 3 | 3 | 3 |
| WebGoat/App_Code/DB/SqliteDbProvider.cs | FAIL | 10 | 10 | 10 |
| WebGoat/App_Data/XmlInjectionUsers.xml | FAIL | 1 | 2 | 2 |
| WebGoat/Code/DatabaseUtilities.cs | FAIL | 5 | 5 | 5 |
| WebGoat/Code/IOHelper.cs | NEEDS_HUMAN | 1 | 2 | 2 |
| WebGoat/Code/SQLiteMembershipProvider.cs | FAIL | 3 | 3 | 2 |
| WebGoat/Code/SQLiteProfileProvider.cs | FAIL | 2 | 2 | 0 |
| WebGoat/Code/SQLiteRoleProvider.cs | FAIL | 3 | 3 | 3 |
| WebGoat/Configuration/Default.config | NEEDS_HUMAN | 0 | 0 | 0 |
| WebGoat/Content/About.aspx.cs | NEEDS_HUMAN | 0 | 1 | 0 |
| WebGoat/Content/About.aspx.designer.cs | NEEDS_HUMAN | 0 | 0 | 0 |
| WebGoat/Content/BasicAuth.aspx.cs | FAIL | 0 | 2 | 1 |
| WebGoat/Content/BasicAuth.aspx.designer.cs | NEEDS_HUMAN | 0 | 0 | 0 |
| WebGoat/Content/Challenge1.aspx.cs | FAIL | 0 | 2 | 2 |
| WebGoat/Content/Challenge1.aspx.designer.cs | NEEDS_HUMAN | 0 | 2 | 0 |
| WebGoat/Content/Challenge2.aspx.cs | FAIL | 0 | 2 | 2 |
| WebGoat/Content/Challenge2.aspx.designer.cs | NEEDS_HUMAN | 0 | 2 | 0 |
| WebGoat/Content/Challenge3.aspx.cs | NEEDS_HUMAN | 0 | 2 | 0 |
| WebGoat/Content/Challenge3.aspx.designer.cs | NEEDS_HUMAN | 0 | 1 | 0 |
| WebGoat/Content/ChangePwd.aspx.cs | FAIL | 0 | 2 | 2 |
