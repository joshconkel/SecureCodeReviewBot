# Security Review: WebGoat/WebGoat.NET.csproj

## Gate Decision: NEEDS_HUMAN

## Rationale
- FND-003 is a confirmed High severity finding related to an outdated MySQL Data Provider, which has no corresponding fix entry in fixes_json.
- Although a proposed fix exists for FND-003 in the fixes_json, it has not been applied yet, and therefore the finding remains unaddressed.
- The policy requires that all confirmed High severity findings must be addressed with a fix before a PASS decision can be made.

## Blockers
- **FND-003** [High, conf=0.9]: Upgrade the MySql.Data package reference to a supported version and ensure database interaction code is tested.

## Confirmed Findings
- **FND-001** [Medium] Debug Mode Enabled in MSBuild Configuration (Other, conf=0.9)
  - Trace: MSBuild Debug config -> DefineConstants=DEBUG
- **FND-002** [Medium] Verbose Environment Variables Set in Debug Configuration (Other, conf=0.85)
  - Trace: MSBuild Debug config -> EnvironmentVariables set
- **FND-003** [High] Use of Outdated MySQL Data Provider (SupplyChain, conf=0.9)
  - Trace: Project file -> MySql.Data v6.4.4.0 reference

## Proposed Fixes (NOT yet applied to codebase)
> ⚠ These fixes are recommendations only. The findings remain open until
> the code changes are implemented, reviewed, and re-scanned.

- **FND-001** [Medium] Debug Mode Enabled in MSBuild Configuration
  - Minimal fix: Remove debug configuration from production build settings to prevent exposing internal state.
  - Better fix:  Ensure that no debug symbols or environment variables are present in any build configuration used for production.
- **FND-002** [Medium] Verbose Environment Variables Set in Debug Configuration
  - Minimal fix: Remove environment variables from the debug configuration to prevent information leakage.
  - Better fix:  Completely disable environment variable injection in non-debug builds and use a centralized config system.
- **FND-003** [High] Use of Outdated MySQL Data Provider
  - Minimal fix: Upgrade the MySql.Data package reference to a supported version.
  - Better fix:  Replace the direct reference with a NuGet package manager approach to ensure latest stable version is used.

## Questions for Humans
- Should the project be built in Debug mode in production?
- Are there any runtime code files that could confirm SQL injection or auth checks?

## Scope Risk Signal: Medium
- The project uses several database providers including MySql and Sqlite which may introduce vulnerabilities if not properly configured.
- No explicit security controls or middleware are visible in the project file, suggesting potential gaps in authentication and authorization layers.
