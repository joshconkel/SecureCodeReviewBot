# Security Review: WebGoat/App_Data/XmlInjectionUsers.xml

## Gate Decision: NEEDS_HUMAN

## Rationale
- The finding FND-001 is confirmed with High severity and confidence of 0.85, which meets the threshold for requiring human review according to the policy.
- Although a fix has been proposed for FND-001, it has not yet been applied, so the finding remains open.

## Blockers
- None

## Confirmed Findings
- **FND-001** [High] XML External Entity (XXE) Injection Vulnerability (Injection, conf=0.85)
  - Trace: XmlInjectionUsers.xml->XXE parser->file read SSRF

## Proposed Fixes (NOT yet applied to codebase)
> ⚠ These fixes are recommendations only. The findings remain open until
> the code changes are implemented, reviewed, and re-scanned.

- **FND-001** [High] XML External Entity (XXE) Injection Vulnerability
  - Minimal fix: Disable external entity processing in XML parser to prevent XXE injection.
  - Better fix:  Use a secure XML parser that disables DTDs and external entities by default, with input validation.

## Scope Risk Signal: Medium
- The addition of a new XML file may introduce new attack vectors if not properly sanitized or validated in usage.
- XML injection vulnerabilities are often present when user-provided input is used to construct XML without proper escaping or validation.
