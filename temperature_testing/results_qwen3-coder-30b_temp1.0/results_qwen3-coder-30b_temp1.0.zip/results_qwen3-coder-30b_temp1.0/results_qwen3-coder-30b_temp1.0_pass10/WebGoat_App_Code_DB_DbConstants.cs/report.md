# Security Review: WebGoat/App_Code/DB/DbConstants.cs

## Gate Decision: NEEDS_HUMAN

## Rationale
- FND-001 is a confirmed High severity finding with confidence 0.9, but no matching entry in fixes_json for this specific finding (only entries for FND-001 and FND-002 exist in fixes_json, but FND-001 is not considered addressed).
- FND-002 is a confirmed Medium severity finding with confidence 0.85, but no matching entry in fixes_json for this specific finding (only entries for FND-001 and FND-002 exist in fixes_json, but FND-002 is not considered addressed).
- The inconclusive_high_severity findings must be reviewed by a human because they may represent actual security risks that require further investigation.
- There are uncovered_pre_scan_findings which must be reviewed by a human unless explicitly refuted.

## Blockers
- None

## Confirmed Findings
- **FND-001** [High] Potential Hardcoded Database Credentials (Secrets, conf=0.9)
  - Trace: DbConstants.cs:15-16 -> constants defined for database user and password keys
- **FND-002** [Medium] Database Configuration Values Exposed (DataLeak, conf=0.85)
  - Trace: DbConstants.cs:10-13 -> database configuration constants exposed

## Proposed Fixes (NOT yet applied to codebase)
> ⚠ These fixes are recommendations only. The findings remain open until
> the code changes are implemented, reviewed, and re-scanned.

- **FND-001** [High] Potential Hardcoded Database Credentials
  - Minimal fix: Remove the database credentials key constants to reduce exposure of potential sensitive configuration keys.
  - Better fix:  Restructure the DbConstants class to avoid exposing database configuration keys that could aid attackers in understanding data access patterns.
- **FND-002** [Medium] Database Configuration Values Exposed
  - Minimal fix: Remove potentially sensitive database configuration key constants to reduce attack surface.
  - Better fix:  Restructure constants to avoid exposing configuration keys that may help attackers understand database access patterns.

## Questions for Humans
- Are there any database connection implementation files that use these KEY_UID and KEY_PWD constants?

## Scope Risk Signal: Low
- This is a simple constants file with no logic or security controls.
- No authentication, authorization, or input validation controls are removed or altered.
- The change adds configuration keys for database types and scripts, which are typically benign additions.
